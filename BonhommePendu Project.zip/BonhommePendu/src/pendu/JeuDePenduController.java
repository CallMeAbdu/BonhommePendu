/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pendu;


import com.sun.javafx.scene.SceneHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import java.util.Random;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Admin
 */
public class JeuDePenduController implements Initializable {
    
    //On initialize avec un score et un nombre d'erreurs de zéro
    StringBuilder motAfficher = new StringBuilder("");
    String motCacher;
    int nbScore=0;
    int nbErreurs=0;
          
    
    ArrayList<String> listeMots = new ArrayList<String>();
    
      @FXML
    private ImageView img;
     
     @FXML
    private TextField motTextField;

    @FXML
    private TextField nomTextField;

    @FXML
    private TextField scoreTextField;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //On crée les mots ci-dessous
        String mot1 = "CUISINE";
        String mot2 = "CHAMBRE";
        String mot3 = "TOILETTE";
        String mot4 = "MANTEAU";
        String mot5 = "GARAGE";
        String mot6 = "ESCALIER";
        String mot7 = "TABLE";
        String mot8 = "ORDINATEUR";
        String mot9 = "BUREAU";
        String mot10 = "SOULIERS";
        String mot11 = "BANANE";
        String mot12 = "POMME";
        String mot13 = "ORANGE";
        String mot14 = "FRAISE";
        String mot15 = "FIGUE";
        
        //on ajoute les mots dans la liste de mots
        listeMots.add(mot1);
        listeMots.add(mot2);
        listeMots.add(mot3);
        listeMots.add(mot4);
        listeMots.add(mot5);
        listeMots.add(mot6);
        listeMots.add(mot7);
        listeMots.add(mot8);
        listeMots.add(mot9);
        listeMots.add(mot10);
        listeMots.add(mot11);
        listeMots.add(mot12);
        listeMots.add(mot13);
        listeMots.add(mot14);
        listeMots.add(mot15);
        
        //On choisi un mot aléatoire de la liste de mots
        Random randomMot = new Random(); 
        int index = randomMot.nextInt(listeMots.size());
        motCacher = listeMots.get(index);
        
        //On rajoute le nombre d'étoiles affichés et ils correspondent au nombre de lettre à trouver
        for (int i=0; i < motCacher.length(); i++){
           motAfficher.append("*");
        }
        
        //On set l'image d'acccueil, le score à 0 et le mot caché dans leurs endroit respectifs
        Image img1 = new Image("file:images/acceuil.jpg");
        img.setImage(img1);
        motTextField.setText(motAfficher.toString());
        scoreTextField.setText("0");
        
    }//fin initialize

@FXML
    void lettre_click(ActionEvent event){ //action event lors d'un click d'une lettre
        
        //On crée des nouvelles image en accédant au document du NetBeans project
        Image imgError1 = new Image("file:images/err1.jpg");
        Image imgError2 = new Image("file:images/err2.jpg");
        Image imgError3 = new Image("file:images/err3.jpg");
        Image imgError4 = new Image("file:images/err4.jpg");
        Image imgError5 = new Image("file:images/err5.jpg");
        Image imgError6 = new Image("file:images/err6.jpg");
        
        //Le button cliqué devient inutilisable
        ((Button)event.getSource()).setDisable(true);

        //On cherche le texte du bouton
        Button btnClick = (Button)event.getSource();
        char choixLettre = btnClick.getText().charAt(0);
        
        int nbOccurences = 0;
        
        //On compare la lettre choisie avec chaucune des lettres du mot à deviner.
        //Si la lettre choisie est égal à la lettre du index du mot. Le score et le nombre d'occurence s'incrémente.
        //Le score sera mis à jour et les lettre cachés seront dévoilées
        for (int i = 0; i < motCacher.length(); i++){   
            if (choixLettre == motCacher.charAt(i)) {
                nbOccurences++;
                nbScore++;
                scoreTextField.setText(String.valueOf(nbScore));
                motAfficher.replace(i, i+1, String.valueOf(choixLettre));
                motTextField.setText(String.valueOf(motAfficher));
                } 
            
        }
            //si la lettre choisie ne revient aucune fois, le nombre d'erreurs augmente de +1
            if(nbOccurences==0){
                 nbErreurs++; 
            }
            
            //L'image change dépendamment du nombre d'erreurs
            switch (nbErreurs) {
                case 1:
                    img.setImage(imgError1);
                    break;
                case 2:
                    img.setImage(imgError2);
                    break;
                case 3:
                    img.setImage(imgError3);
                    break;
                case 4:
                    img.setImage(imgError4);
                    break;
                case 5:
                    img.setImage(imgError5);
                    break;
                case 6:
                    img.setImage(imgError6);
                    break;
                default:
                    break;
            }
            
            //Si le nombre d'erreurs est de 6, la partie est perdue et la fenetre se fermera.
            if (nbErreurs == 6) {
                Alert a = new Alert(Alert.AlertType.INFORMATION);
                a.setTitle("Perdant");
                a.setHeaderText("Vous avez perdu, le mot à trouver était: "+motCacher + "  la fenêtre se fermera et vous pourriez rejouer");
                a.show();
                 
                Stage stage = (Stage) btnClick.getScene().getWindow();
                stage.close();
            }
             
             //Si le mot affiché est égal au mot caché, la partie est perdue et la fenetre se fermera
            else {
                if(motAfficher.toString().equals(motCacher)){
                     Alert a = new Alert(Alert.AlertType.INFORMATION);
                     a.setTitle("Gagnant");
                     a.setHeaderText("Vous avez gagné, la fenêtre se fermera et vous pourriez rejouer");
                     a.show();
                     
                     Stage stage = (Stage) btnClick.getScene().getWindow();
                     stage.close();
                }
                     
            }
      
    }//fin action event du click d'une lettre    
    
}//fin controller
