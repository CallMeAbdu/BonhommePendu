/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pendu;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import static javafx.application.ConditionalFeature.FXML;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Admin
 */
public class LoginController implements Initializable {
    
    
    @FXML
    private Button jouer;

    @FXML
    private Button quitter;
    
    @FXML
    private TextField nom;

    @FXML
    void jouer_isClicked(ActionEvent event) throws IOException {//action event pour acceder au jeu
        
        if (nom.getText().isEmpty()){//si le text field nom est vide, une alerte sera afficher
            Alert a = new Alert(Alert.AlertType.INFORMATION);
                a.setTitle("Nom manquant");
                a.setHeaderText("Vous devez inserer un nom");
                a.show();
        }
       
        else{//sinon on set la fenetre de jeu
        Parent root = null;
        Stage s = new Stage();
        root = FXMLLoader.load(getClass().getResource("JeuDePendu.fxml"));
        Scene scene = new Scene(root);
        s.setTitle("Jeu de pendu");
        s.setScene(scene);
        s.show();
        
        //le nom ecrit dans le textfield nom sera sauvegarder
        ((TextField)scene.lookup("#nomTextField")).setText(nom.getText());
        }
    }//fin action event
    

    @FXML
    void quitter_isClicked(ActionEvent event) {//action event pour quitter 
     System.exit(0);
    }//fin action event
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}//fin controller
